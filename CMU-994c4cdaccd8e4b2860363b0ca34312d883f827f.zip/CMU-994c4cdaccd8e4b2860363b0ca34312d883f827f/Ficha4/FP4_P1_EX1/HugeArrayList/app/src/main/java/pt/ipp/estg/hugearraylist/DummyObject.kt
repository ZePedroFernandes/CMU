package pt.ipp.estg.hugearraylist


class DummyObject(
    val src: Int,
    val number: Int
) {


}