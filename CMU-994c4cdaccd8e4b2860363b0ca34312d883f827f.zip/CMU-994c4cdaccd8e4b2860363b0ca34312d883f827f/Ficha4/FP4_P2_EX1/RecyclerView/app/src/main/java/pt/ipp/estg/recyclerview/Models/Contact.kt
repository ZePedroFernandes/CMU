package pt.ipp.estg.recyclerview.Models

class Contact(
    val name: String,
    val online: Boolean
) {
}