package pt.ipp.estg.contactlist

interface ContactCommunication {

    fun contactCreated()
}