package pt.ipp.estg.contactlist.models

class Contact(
    val name: String,
    val phone: Int) {
}